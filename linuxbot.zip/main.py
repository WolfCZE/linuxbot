import discord
from discord.ext import commands, tasks, message
import requests
import random
from random import randint
import asyncio
import sys
from yaml import safe_load
import colorama
from colorama import Fore, Style
import os
from discord.utils import get
import time
import subprocess

# hwid = str(str(subprocess.check_output('wmic csproduct get uuid')).strip().replace(r"\r", "").split(r"\n")[1].strip())
# r = requests.get("PASTEBINRAWLINK")

os.system('cls')

config_exist = os.path.isfile('config.yml')
try:
    config = safe_load(open('config.yml', 'r', encoding='utf-8', errors='ignore'))
    token = str(config['token'])
    logs = str(config['logs'])
    sellix_api_key = str(config['sellix_api_key'])
    prefix = str(config['prefix'])
    status = str(config['status'])
except Exception as e:
    print(e)
    sys.exit()

def printSlow(text):
    for char in text:
        print(char, end="")
        sys.stdout.flush()
        time.sleep(.1)

# def Main_Program():
#    if hwid in r.text:
#        time.sleep(.1)
#    else:
#        print("User not authorized!")
#        print("Contact (YOURDISCORDNAME) to add your HWID. HWID: " + hwid)
#        sys.exit()

# Main_Program()
intents = discord.Intents.all()
bot = commands.Bot(command_prefix=prefix, case_insensitive=True,intents=intents)

bot.remove_command("help")
colors = [0xFFE4E1, 0x00FF7F, 0xD8BFD8, 0xDC143C, 0xFF4500, 0xDEB887, 0xADFF2F, 0x800000, 0x4682B4, 0x006400, 0x808080, 0xA0522D, 0xF08080, 0xC71585, 0xFFB6C1, 0x00CED1]


@bot.event
async def on_ready():
    os.system('cls')
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=status))
    print(f"\x1b[94m[\x1b[0mSN\x1b[94m] {Fore.LIGHTBLUE_EX}Logged in as {Fore.WHITE}{bot.user.name}#{bot.user.discriminator}{Style.RESET_ALL}")
    print(f"\x1b[94m[\x1b[0mSN\x1b[94m] {Fore.LIGHTBLUE_EX}Prefix {Fore.WHITE}{prefix}{Style.RESET_ALL}")
    print(f"\x1b[94m[\x1b[0mSN\x1b[94m] {Fore.LIGHTBLUE_EX}Status {Fore.WHITE}{status}{Style.RESET_ALL}")

@bot.command()
@commands.has_permissions(administrator=True)
async def info(ctx, order_id):
    headers = {
        'Authorization': f'Bearer {sellix_api_key}',
    }
    response = requests.get(f'https://dev.sellix.io/v1/orders/{order_id}', headers=headers).json()
    embed = discord.Embed(title="`✅` Order Info", description=f"Order ID: {order_id}", color=0x4BB543)
    embed.add_field(name="Product Name", value=response['data']['order']['product_title'], inline=False)
    embed.add_field(name="Created At", value=f"<t:{response['data']['order']['created_at']}>", inline=False)
    embed.add_field(name="Status", value=response['data']['order']['status'], inline=False)
    embed.add_field(name="Gateway", value=response['data']['order']['gateway'], inline=False)
    embed.add_field(name="Quantity", value=response['data']['order']['quantity'], inline=False)
    await ctx.reply(embed=embed)

@bot.command()
async def redeem(ctx, order_id):
    headers = {
        'Authorization': f'Bearer {sellix_api_key}',
    }
    response = requests.get(f'https://dev.sellix.io/v1/orders/{order_id}', headers=headers).json()
    orderr = response['data']['order']['status']    
    if orderr == "VOIDED":
        embed = discord.Embed(title="`❌` Order Not Processed", description=f"Order ID: `{order_id}` was not processed.", color=0xD0342C)
        await ctx.reply(embed=embed)
        return
    asd = response['status']
    if asd == 404:
        embed = discord.Embed(title="`❌` Order ID Not Found", description=f"Order ID: `{order_id}`", color=0xFF0000)
        await ctx.reply(embed=embed)
    if order_id in open("id.storage", "r").read():
        embed = discord.Embed(title="`⚠️` Order ID Already Redeemed", description=f"Order ID: `{order_id}`", color=0xffcc00)
        await ctx.reply(embed=embed)
        return
    if asd == 200:
        with open("id.storage", "a") as f:
            f.write(order_id + "\n")
        embed = discord.Embed(title="`✅` Order Successfully Redeemed", description=f"Order ID: `{order_id}`", color=0x4BB543)
        await ctx.reply(embed=embed)
        role = get(message.server.roles, id='ENTER CUSTOMER ROLE ID')
        await client.add_roles(message.author, role)
        return

@bot.command()
async def stock(ctx):
    headers = {
        'Authorization': f'Bearer {sellix_api_key}',
    }
    response = requests.get(f'https://dev.sellix.io/v1/products', headers=headers).json()
    embed = discord.Embed(title="Stock", description=f"Showing all products", color=5814783)
    for product in response['data']['products']:
        embed.add_field(name=product['title'], value=f"Stock: {product['stock']}", inline=False)
    await ctx.reply(embed=embed)

@bot.command()
async def coupons(ctx):
    headers = {
        'Authorization': f'Bearer {sellix_api_key}',
    }
    response = requests.get(f'https://dev.sellix.io/v1/coupons', headers=headers).json()
    embed = discord.Embed(title="Coupons", description=f"Showing all cupons", color=5814783)
    for cupon in response['data']['coupons']:
        embed=discord.Embed(title="`🎗️` Coupouns", description=f"`{cupon['code']}` Discount: {cupon['discount']}%", color=0x4BB543)
    await ctx.reply(embed=embed)   

@bot.command()
@commands.has_permissions(administrator=True)
async def orders(ctx):
    headers = {
        'Authorization': f'Bearer {sellix_api_key}',
    }
    response = requests.get(f'https://dev.sellix.io/v1/orders', headers=headers).json()
    embed = discord.Embed(title="Orders", description=f"Showing all orders", color=random.choice(colors))
    for order in response['data']['orders']:
        if order['status'] == "COMPLETED":
            embed.add_field(name=f"Order ID: {order['uniqid']}", value=f"Customer Email: {order['customer_email']}\nProduct Name: {order['product_title']}\nCreated At: <t:{order['created_at']}>\nStatus: {order['status']}\nPrice: {order['total']}$\nGateway: {order['gateway']}\nQuantity: {order['quantity']}", inline=False)
    await ctx.reply(embed=embed)
    
@bot.command()
async def help(ctx):
    embed = discord.Embed(title="`📚` Help", description=f"`{prefix}info <order_id>` - Order ID info\n`{prefix}orders` - Get all Valid Orders\n`{prefix}redeem` - Redeem Order ID\n`{prefix}stock` - Get all stock from your sellix shop\n`{prefix}coupons` - Show all coupons", color=0x00ff00)
    await ctx.reply(embed=embed)
bot.run(token)   